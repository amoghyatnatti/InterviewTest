﻿namespace InterviewTest.Products
{
    public interface IProduct
    {
        string GetProductNumber();
        float GetSellingPrice();
    }
}
