﻿namespace InterviewTest.Products
{
    public class HitchAdapter : IProduct
    {
        public float GetSellingPrice()
        {
            return 70;
        }

        public string GetProductNumber()
        {
            return "DrawTite 5504";
        }
    }
}
